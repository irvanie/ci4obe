<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <h1>Hello, My Name Irfan Evandio</h1>
            <p>I have make some website for calculate your BMI and knowing you're healty or not. hope you enjoy with this website, thanks!</p>
        </div>
    </div>
</div>
<?= $this->endSection(''); ?>