<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <div class="panel">
                <h2 class="text-center">Cek Berat Badan Idealmu</h2>
                <p id="introText" class="text-center">Berikut adalah data berat dan tinggi kamu</p>
                <center>
                    <form>
                        <div id="weightInput">
                            <p>Put your weight in here (KG) </p>
                            <input id="weight" type="number" pattern="[0-9]*" name="a" value='<?php echo session()->get('berat') ?>' readonly />
                        </div>
                        <div id="heightInput">
                            <p>And your height in here (CM)</p>
                            <input id="height" type="number" pattern="[0-9]*" name="b" value='<?php echo session()->get('tinggi') ?>' readonly />
                        </div>
                    </form>
                    <h3> Hello, <?php echo session()->get('nama') ?></h3>
                    <div id="results" class="text-center">Your BMI results will appear here</div>
                    <p> Dari Hasil Diatas kamu bisa mengetahui berat badan kamu sudah ideal atau belum, kamu dapat menghitung berat badan yang sesuai dengan badanmu. </p>
            </div>
            </center>
        </div>
    </div>
</div>
<script src="/main.js"></script>
<?= $this->endSection(''); ?>