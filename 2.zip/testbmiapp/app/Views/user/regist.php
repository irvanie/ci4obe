<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <form action="/user/save" method="post">
                <?= csrf_field(); ?>
                <div class="form-group">
                    <label for="nama">nama</label>
                    <input class="form-control" type="text" placeholder="Default input" id="nama" name="nama" autofocus>
                </div>
                <div class="form-group">
                    <label for="email">Email address</label>
                    <input type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter email" name="email">
                    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                </div>
                <div class="form-group">
                    <label for="nohp">No Handphone</label>
                    <input class="form-control" type="text" placeholder="Default input" id="nohp" name="nohp">
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" placeholder="Password" id="password" name="password">
                </div>
                <div class="form-group">
                    <label for="repassword">Retype Password</label>
                    <input type="password" class="form-control" placeholder="Retype Password" id="repassword" name="repassword">
                </div>
                <div class="form-group">
                    <label for="berat">Berat Badan</label>
                    <input class="form-control" type="text" placeholder="Default input" id="berat" name="berat">
                </div>
                <div class="form-group">
                    <label for="tinggi">Tinggi Badan</label>
                    <input class="form-control" type="text" placeholder="Default input" id="tinggi" name="tinggi">
                </div>
                <center>
                    <button type="submit" class="btn btn-primary">Let's Go</button>
                </center>
            </form>
        </div>
    </div>
</div>
<?= $this->endSection(''); ?>