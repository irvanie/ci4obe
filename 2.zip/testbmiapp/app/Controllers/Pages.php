<?php

namespace App\Controllers;

class Pages extends BaseController
{
    public function index()
    {
        return view('welcome_message');
    }

    public function home()
    {
        $data = [
            'title' => 'Home | BMI KALKULATOR IRFAN'
        ];
        return view('pages/home', $data);
    }

    public function about()
    {
        $data = [
            'title' => 'About | BMI KALKULATOR IRFAN'
        ];
        return view('pages/about', $data);
    }

    public function yourbmi()
    {
        $data = [
            'title' => 'Your BMI | BMI KALKULATOR IRFAN'
        ];
        $sess = session()->get('logged_in');


        return view('pages/yourbmi', $data);
    }
}
