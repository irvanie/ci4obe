<?php

namespace App\Controllers;

use App\Models\UserModel;

class User extends BaseController
{
    protected $userModel;
    public function __construct()
    {
        $this->userModel = new UserModel();
    }
    public function index()
    {
        $data = [
            'title' => 'Login User | BMI KALKULATOR IRFAN'
        ];

        return view('user/login', $data);
    }
    public function regist()
    {
        $register = [];
        $data = [
            'title' => 'Login | BMI KALKULATOR IRFAN'
        ];

        $user = $this->userModel->findAll();
        return view('user/regist', $data);
    }

    public function save()
    {
        helper(['form']);
        $rules = [
            'nama'          => 'required|min_length[3]|max_length[20]',
            'email'         => 'required|min_length[6]|max_length[50]|valid_email|is_unique[userbmi.email]',
            'password'      => 'required|min_length[6]|max_length[200]',
            'repassword'  => 'matches[password]'
        ];

        if ($this->validate($rules)) {
            $register = $this->userModel->save([
                'nama' => $this->request->getVar('nama'),
                'email' => $this->request->getVar('email'),
                'nohp' => $this->request->getVar('nohp'),
                'password' => $this->request->getVar('password'),
                'berat' => $this->request->getVar('berat'),
                'tinggi' => $this->request->getVar('tinggi'),
            ]);
        } else {
            $register['validation'] = $this->validator;
        }
        return redirect()->to('/user');

        // dd($this->request->getVar());
    }

    public function logout()
    {
        $session = session();
        $session->destroy();
        return redirect()->to('/login');
    }
}
