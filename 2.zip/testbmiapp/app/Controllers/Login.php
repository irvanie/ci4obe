<?php

namespace App\Controllers;

use App\Models\UserModel;

class Login extends BaseController
{
    protected $userModel;
    public function __construct()
    {
        $this->userModel = new UserModel();
    }
    public function index()
    {
        $data = [
            'title' => 'Login | BMI KALKULATOR IRFAN'
        ];
        helper(['form']);
        return view('user/login', $data);
    }

    public function auth()
    {
        $data = [
            'title' => 'Login | BMI KALKULATOR IRFAN'
        ];
        $session = session();
        $user = new UserModel();
        $email = $this->request->getVar('email');
        $password = $this->request->getVar('password');
        $data = $user->where('email', $email)->first();
        // dd($data);

        if ($data) {
            $pass = $data['password'];
            // $verify_pass = password_verify($password, $pass);
            if ($password == $pass) {
                $ses_data = [
                    'id'       => $data['id'],
                    'nama'     => $data['nama'],
                    'email'    => $data['email'],
                    'berat'     => $data['berat'],
                    'tinggi'    => $data['tinggi'],
                    'logged_in'     => TRUE
                ];
                $session->set($ses_data);
                return redirect()->to('pages/home');
            } else {
                $session->setFlashdata('msg', 'Wrong Password');
                return redirect()->to('/login');
            }
        } else {
            $session->setFlashdata('msg', 'Email not Found');
            return redirect()->to('/login');
        }
    }

    public function logout()
    {
        $session = session();
        $session->destroy();
        return redirect()->to('/login');
    }
}
